import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppointmentDTO } from '../models/appointment.model';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private baseUrl = 'http://localhost:8081/springsecurity/api/v1';

  constructor(private http: HttpClient) {}

  getPatientAppointments(patientId: number): Observable<AppointmentDTO[]> {
    return this.http.get<AppointmentDTO[]>(
      `${this.baseUrl}/appointments/patients/${patientId}/appointments`
    );
  }

  getDoctorAppointments(doctorId: number, date?: string): Observable<AppointmentDTO[]> {
    let params = new HttpParams();
    if (date) {
      params = params.set('date', date);
    }
    // Matching backend: @RequestMapping("/api/v1/appointments") + @GetMapping("/doctors/{doctorId}")
    return this.http.get<AppointmentDTO[]>(`${this.baseUrl}/appointments/doctors/${doctorId}`, { params });
  }

  cancelAppointment(id: number): Observable<void> {
    return this.http.post<void>(
      `${this.baseUrl}/appointments/${id}/cancel`, {}
    );
  }
}
