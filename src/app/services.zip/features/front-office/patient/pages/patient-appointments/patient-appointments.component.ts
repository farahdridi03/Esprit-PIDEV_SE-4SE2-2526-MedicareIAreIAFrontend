import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../../../../../services/appointment.service';
import { AppointmentDTO } from '../../../../../models/appointment.model';
import { AuthService } from '../../../../../services/auth.service';

@Component({
  selector: 'app-patient-appointments',
  templateUrl: './patient-appointments.component.html',
  styleUrls: ['./patient-appointments.component.scss']
})
export class PatientAppointmentsComponent implements OnInit {
  appointments: AppointmentDTO[] = [];
  upcomingAppointments: AppointmentDTO[] = [];
  pastAppointments: AppointmentDTO[] = [];
  cancelledAppointments: AppointmentDTO[] = [];
  activeTab: string = 'upcoming';
  isLoading = false;

  constructor(
    private appointmentService: AppointmentService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadAppointments();
  }

  loadAppointments(): void {
    this.isLoading = true;
    const patientId = this.authService.getUserId();
    
    if (!patientId) {
      this.isLoading = false;
      return;
    }

    this.appointmentService.getPatientAppointments(patientId)
      .subscribe({
        next: (data) => {
          this.appointments = data;
          const today = new Date().toISOString().split('T')[0];
          
          this.upcomingAppointments = data.filter(a =>
            a.date >= today && (a.status === 'BOOKED' || a.status === 'RESCHEDULED')
          );
          this.pastAppointments = data.filter(a =>
            (a.date < today && a.status !== 'CANCELLED') || a.status === 'COMPLETED'
          );
          this.cancelledAppointments = data.filter(a =>
            a.status === 'CANCELLED'
          );
          this.isLoading = false;
        },
        error: (err) => {
          console.error('[ERROR] load appointments:', err);
          this.isLoading = false;
        }
      });
  }

  cancelAppointment(id: number): void {
    if (!confirm('Cancel this appointment?')) return;
    this.appointmentService.cancelAppointment(id).subscribe({
      next: () => this.loadAppointments(),
      error: (err) => console.error('[ERROR] cancel:', err)
    });
  }
}
