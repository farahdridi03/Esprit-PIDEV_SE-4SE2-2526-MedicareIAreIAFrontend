import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';

export interface BabyProfile {
  id: number;
  name: string;
  birthDate: string;
  gender: string;
  birthWeight: number;
  birthHeight: number;
  parentId: number;
  photoUrl?: string; // Base64 or Blob URL
  priorities?: string[];
}

export interface BabyDashboard {
  id: number;
  name: string;
  ageText: string;
  ageDays: number;
  weightAtBirth: number;
  heightAtBirth: number;
  photoUrl?: string;
  dailyTip: string;
  aiContextualMessage: string;
  lastFeedingText: string;
  sleepQualityText: string;
  nextVaccineName: string;
  nextVaccineDate: string;
  nextCheckupDate: string;
  milestoneProgress: number;
}

export interface VaccineDefinition {
  id: string;
  name: string;
  milestoneAgeDays: number;
  description?: string;
  doseNumber?: number;
}

export interface VaccineRecord {
  id: number;
  babyId: number;
  vaccineId: string;
  completionDate: string;
  notes?: string;
}

export interface ComputedVaccineStatus {
  definition: VaccineDefinition;
  status: 'done' | 'due now' | 'upcoming soon' | 'overdue' | 'not yet due';
  record?: VaccineRecord | null;
  dueDateText: string;
  dueAgeText: string;
  daysUntilDue: number;
}

export interface VaccineDashboardData {
  dueNow: ComputedVaccineStatus[];
  upcoming: ComputedVaccineStatus[];
  completed: ComputedVaccineStatus[];
  notYetDue: ComputedVaccineStatus[];
  progressPercentage: number;
  nextVaccine: ComputedVaccineStatus | null;
}

const VACCINE_SCHEDULE: VaccineDefinition[] = [
  { id: 'bcg', name: 'BCG — Tuberculosis', milestoneAgeDays: 0, description: 'Protects against tuberculosis.' },
  { id: 'hepb_1', name: 'Hepatitis B', milestoneAgeDays: 0, doseNumber: 1, description: 'First dose protecting against liver disease.' },
  { id: 'pentavalent_1', name: 'Pentavalent 1', milestoneAgeDays: 60, doseNumber: 1, description: 'Diphtheria, Tetanus, Pertussis, Hep B, Hib.' },
  { id: 'opv_1', name: 'Oral Polio (OPV 1)', milestoneAgeDays: 60, doseNumber: 1, description: 'Polio protection.' },
  { id: 'rotavirus_1', name: 'Rotavirus 1', milestoneAgeDays: 60, doseNumber: 1, description: 'Prevents severe diarrhea and dehydration.' },
  { id: 'pentavalent_2', name: 'Pentavalent 2', milestoneAgeDays: 120, doseNumber: 2, description: 'Second dose reinforcing protection.' },
  { id: 'opv_2', name: 'Oral Polio (OPV 2)', milestoneAgeDays: 120, doseNumber: 2, description: 'Continued polio protection.' },
  { id: 'rotavirus_2', name: 'Rotavirus 2', milestoneAgeDays: 120, doseNumber: 2, description: 'Second rotavirus dose.' },
  { id: 'pentavalent_3', name: 'Pentavalent 3', milestoneAgeDays: 180, doseNumber: 3, description: 'Third dose for lasting immunity.' },
  { id: 'opv_3', name: 'Oral Polio (OPV 3)', milestoneAgeDays: 180, doseNumber: 3, description: 'Continued polio protection.' },
  { id: 'mmr_1', name: 'MMR', milestoneAgeDays: 365, doseNumber: 1, description: 'Measles, Mumps, Rubella protection.' }
];


@Injectable({
  providedIn: 'root'
})
export class BabyCareService {
  private STORAGE_KEY_PROFILES = 'fbc_profiles';
  private STORAGE_KEY_JOURNAL = 'fbc_journal';
  private STORAGE_KEY_VACCINES = 'fbc_vaccines';
  
  constructor() {}

  // Helpers
  private getVaccineRecords(): VaccineRecord[] {
    const data = localStorage.getItem(this.STORAGE_KEY_VACCINES);
    return data ? JSON.parse(data) : [];
  }

  private saveVaccineRecords(records: VaccineRecord[]): void {
    localStorage.setItem(this.STORAGE_KEY_VACCINES, JSON.stringify(records));
  }
  private getProfiles(): BabyProfile[] {
    const data = localStorage.getItem(this.STORAGE_KEY_PROFILES);
    return data ? JSON.parse(data) : [];
  }

  private saveProfiles(profiles: BabyProfile[]): void {
    localStorage.setItem(this.STORAGE_KEY_PROFILES, JSON.stringify(profiles));
  }

  private getJournals(): any[] {
    const data = localStorage.getItem(this.STORAGE_KEY_JOURNAL);
    return data ? JSON.parse(data) : [];
  }

  private saveJournals(journals: any[]): void {
    localStorage.setItem(this.STORAGE_KEY_JOURNAL, JSON.stringify(journals));
  }

  private calculateAge(birthDate: string): string {
    const bday = new Date(birthDate);
    const diff = new Date(Date.now() - bday.getTime());
    const years = diff.getUTCFullYear() - 1970;
    const months = diff.getUTCMonth();
    if (years > 0) return `${years}y ${months}m`;
    else if (months > 0) return `${months}m`;
    else {
      const days = Math.floor((Date.now() - bday.getTime()) / (1000 * 60 * 60 * 24));
      return `${days} days`;
    }
  }

  // API Methods
  createProfile(parentId: number, profileData: any): Observable<BabyProfile> {
    const profiles = this.getProfiles();
    const newProfile: BabyProfile = {
      id: Date.now(),
      parentId: parentId,
      name: profileData.name,
      birthDate: profileData.birthDate,
      gender: profileData.gender || 'UNKNOWN',
      birthWeight: profileData.birthWeight || 0,
      birthHeight: profileData.birthHeight || 0,
      photoUrl: profileData.photoUrl,
      priorities: profileData.priorities || []
    };
    
    // Remove old profiles for this parent if any, and add the new one
    const filtered = profiles.filter(p => p.parentId !== parentId);
    filtered.push(newProfile);
    this.saveProfiles(filtered);
    
    return of(newProfile).pipe(delay(300));
  }

  getProfileByPatientId(patientId: number): Observable<BabyProfile> {
    const profiles = this.getProfiles();
    const profile = profiles.find(p => p.parentId === patientId);
    if (profile) {
      return of(profile).pipe(delay(200));
    }
    return throwError(() => new Error('Not found'));
  }

  getDashboard(babyId: number): Observable<BabyDashboard> {
    const profiles = this.getProfiles();
    const profile = profiles.find(p => p.id === babyId);
    if (!profile) return throwError(() => new Error('Not found'));

    const journals = this.getJournals().filter(j => j.babyId === babyId);
    const lastFeeding = journals.find(j => j.type === 'FEEDING');
    const lastSleep = journals.find(j => j.type === 'SLEEP');
    
    // Calculate age in days for logic
    const ageInDays = Math.floor((Date.now() - new Date(profile.birthDate).getTime()) / (1000 * 60 * 60 * 24));
    
    // Contextual AI Message Logic
    let aiMessage = `Healthy growth detected for ${profile.name}. `;
    if (ageInDays < 30) aiMessage += "Focus on skin-to-skin contact and frequent feeding.";
    else if (ageInDays < 180) aiMessage += "Introduce tummy time sessions to strengthen neck muscles.";
    else aiMessage += "Great stage to start exploring different textures in purees!";

    const dashboard: BabyDashboard = {
      id: profile.id,
      name: profile.name,
      ageText: this.calculateAge(profile.birthDate),
      ageDays: ageInDays,
      weightAtBirth: profile.birthWeight,
      heightAtBirth: profile.birthHeight,
      photoUrl: profile.photoUrl,
      dailyTip: `"At ${this.calculateAge(profile.birthDate)}, ${profile.name} is building new neural pathways every second."`,
      aiContextualMessage: aiMessage,
      lastFeedingText: lastFeeding ? this.getTimeAgo(lastFeeding.timestamp) : 'No logs yet',
      sleepQualityText: lastSleep ? (lastSleep.detail || 'Restful') : 'Log sleep',
      nextVaccineName: ageInDays < 120 ? 'Pentavalent 2' : 'DTP Booster',
      nextVaccineDate: 'Apr 15',
      nextCheckupDate: 'Apr 12',
      milestoneProgress: 65
    };
    return of(dashboard).pipe(delay(100));
  }

  updateProfilePhoto(babyId: number, photoUrl: string): Observable<BabyProfile> {
    const profiles = this.getProfiles();
    const index = profiles.findIndex(p => p.id === babyId);
    if (index !== -1) {
      profiles[index].photoUrl = photoUrl;
      this.saveProfiles(profiles);
      return of(profiles[index]);
    }
    return throwError(() => new Error('Not found'));
  }

  private getTimeAgo(timestamp: number): string {
    const mins = Math.floor((Date.now() - timestamp) / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  }

  getVaccines(babyId: number): Observable<VaccineDashboardData> {
    const profiles = this.getProfiles();
    const profile = profiles.find(p => p.id === babyId);
    if (!profile) return throwError(() => new Error('Profile not found'));

    const records = this.getVaccineRecords().filter(r => r.babyId === babyId);
    const birthDate = new Date(profile.birthDate);
    const ageInDays = Math.floor((Date.now() - birthDate.getTime()) / (1000 * 60 * 60 * 24));

    const computedList: ComputedVaccineStatus[] = VACCINE_SCHEDULE.map(def => {
      const record = records.find(r => r.vaccineId === def.id);
      
      const dueDate = new Date(birthDate.getTime() + def.milestoneAgeDays * 24 * 60 * 60 * 1000);
      const daysUntilDue = def.milestoneAgeDays - ageInDays;
      
      let status: ComputedVaccineStatus['status'] = 'not yet due';
      if (record) {
        status = 'done';
      } else if (daysUntilDue <= 14 && daysUntilDue > -14) {
        status = 'due now';
      } else if (daysUntilDue <= -14) {
        status = 'overdue';
      } else if (daysUntilDue <= 30 && daysUntilDue > 14) {
        status = 'upcoming soon';
      }

      let dueAgeText = '';
      if (def.milestoneAgeDays === 0) dueAgeText = 'Birth';
      else if (def.milestoneAgeDays === 60) dueAgeText = '2 Months';
      else if (def.milestoneAgeDays === 120) dueAgeText = '4 Months';
      else if (def.milestoneAgeDays === 180) dueAgeText = '6 Months';
      else if (def.milestoneAgeDays === 365) dueAgeText = '1 Year';
      else dueAgeText = `${def.milestoneAgeDays} days`;

      return {
        definition: def,
        status,
        record: record || null,
        dueDateText: dueDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        dueAgeText,
        daysUntilDue
      };
    });

    const doneList = computedList.filter(v => v.status === 'done').sort((a,b) => b.definition.milestoneAgeDays - a.definition.milestoneAgeDays);
    const dueNowList = computedList.filter(v => ['due now', 'overdue'].includes(v.status));
    const upcomingList = computedList.filter(v => v.status === 'upcoming soon');
    const notYetDueList = computedList.filter(v => v.status === 'not yet due');

    // Only count relevant vaccines (due so far) for progress
    const relevantVaccinesCount = computedList.filter(v => v.definition.milestoneAgeDays <= ageInDays).length;
    const completedRelevantCount = computedList.filter(v => v.status === 'done' && v.definition.milestoneAgeDays <= ageInDays).length;

    const progressPercentage = relevantVaccinesCount > 0 ? Math.round((completedRelevantCount / relevantVaccinesCount) * 100) : 100;

    let nextVaccine: ComputedVaccineStatus | null = null;
    const notDoneSorted = computedList.filter(v => v.status !== 'done').sort((a,b) => a.definition.milestoneAgeDays - b.definition.milestoneAgeDays);
    if (notDoneSorted.length > 0) {
      nextVaccine = notDoneSorted[0];
    }

    const data: VaccineDashboardData = {
      dueNow: dueNowList,
      upcoming: upcomingList,
      completed: doneList,
      notYetDue: notYetDueList,
      progressPercentage,
      nextVaccine
    };

    return of(data).pipe(delay(200));
  }

  recordVaccineComplete(babyId: number, vaccineId: string, customDate?: string, notes?: string): Observable<VaccineRecord> {
    const records = this.getVaccineRecords();
    const existingIndex = records.findIndex(r => r.babyId === babyId && r.vaccineId === vaccineId);
    let record: VaccineRecord;
    
    if (existingIndex >= 0) {
      record = records[existingIndex];
      if (customDate) record.completionDate = customDate;
      if (notes !== undefined) record.notes = notes;
    } else {
      record = {
        id: Date.now(),
        babyId,
        vaccineId,
        completionDate: customDate || new Date().toISOString().split('T')[0],
        notes
      };
      records.push(record);
    }
    
    this.saveVaccineRecords(records);
    return of(record).pipe(delay(200));
  }

  removeVaccineRecord(recordId: number): Observable<boolean> {
    let records = this.getVaccineRecords();
    const initialLen = records.length;
    records = records.filter(r => r.id !== recordId);
    this.saveVaccineRecords(records);
    return of(records.length < initialLen).pipe(delay(200));
  }

  getJournal(babyId: number): Observable<any[]> {
    const journals = this.getJournals();
    const babyLogs = journals.filter(j => j.babyId === babyId).sort((a,b) => b.timestamp - a.timestamp);
    return of(babyLogs).pipe(delay(200));
  }

  addJournalEntry(babyId: number, type: string, value: string, notes?: string, metadata?: any): Observable<any> {
    const journals = this.getJournals();
    const newEntry = {
      id: Date.now(),
      babyId: babyId,
      timestamp: Date.now(),
      time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
      type: type,
      icon: this.getIconForType(type),
      title: this.getTitleForType(type),
      detail: value,
      badge: this.getBadgeForType(type, value),
      badgeBg: '#f1f5f9',
      badgeColor: '#475569',
      notes: notes,
      ...metadata
    };
    journals.push(newEntry);
    this.saveJournals(journals);
    return of(newEntry).pipe(delay(300));
  }

  private getIconForType(type: string): string {
    const map: any = { 'FEEDING': '🍼', 'SLEEP': '🌙', 'DIAPER': '💧', 'TEMP': '🌡️', 'NOTE': '📝' };
    return map[type] || '📝';
  }

  private getTitleForType(type: string): string {
    const map: any = { 'FEEDING': 'Feeding', 'SLEEP': 'Sleep', 'DIAPER': 'Diaper Change', 'TEMP': 'Temperature', 'NOTE': 'Note' };
    return map[type] || 'Note';
  }

  private getBadgeForType(type: string, value: string): string {
    if (type === 'TEMP') return value.includes('38') ? 'High' : 'Normal';
    if (type === 'FEEDING') return value.includes('ml') ? 'Bottle' : 'Breast';
    return 'Logged';
  }

  getCategorySummaries(babyId: number): Observable<any> {
    const journals = this.getJournals().filter(j => j.babyId === babyId);
    const today = new Date().setHours(0,0,0,0);
    const todayLogs = journals.filter(j => j.timestamp >= today);

    // Sleep
    const sleepLogs = todayLogs.filter(j => j.type === 'SLEEP');
    const totalSleepMins = sleepLogs.reduce((acc, current) => acc + (current.duration || 0), 0);
    
    // Feeding
    const feedingLogs = todayLogs.filter(j => j.type === 'FEEDING');
    const totalMl = feedingLogs.reduce((acc, current) => acc + (current.quantity || 0), 0);

    // Diaper
    const diaperLogs = todayLogs.filter(j => j.type === 'DIAPER');
    const wetCount = diaperLogs.filter(j => j.subType === 'WET' || j.subType === 'MIXED').length;
    const dirtyCount = diaperLogs.filter(j => j.subType === 'DIRTY' || j.subType === 'MIXED').length;

    // Health
    const tempLogs = journals.filter(j => j.type === 'TEMP');
    const latestTemp = tempLogs.length > 0 ? tempLogs[tempLogs.length - 1] : null;

    return of({
      sleep: { totalMins: totalSleepMins, targetMins: 840, count: sleepLogs.length },
      feeding: { totalMl: totalMl, sessionCount: feedingLogs.length, lastTime: feedingLogs.length > 0 ? feedingLogs[0].time : 'N/A' },
      diaper: { total: diaperLogs.length, wet: wetCount, dirty: dirtyCount },
      health: { latest: latestTemp?.value || 'N/A', status: this.getTempStatus(latestTemp?.value) }
    }).pipe(delay(100));
  }

  private getTempStatus(val: string | undefined): string {
    if (!val) return 'Normal';
    const t = parseFloat(val);
    if (t >= 39) return 'High Fever';
    if (t >= 38) return 'Fever';
    if (t >= 37.5) return 'Mild Fever';
    return 'Normal';
  }
}
