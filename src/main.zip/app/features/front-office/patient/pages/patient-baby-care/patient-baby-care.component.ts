import { Component, OnInit } from '@angular/core';
import { BabyCareService, BabyDashboard, BabyProfile, VaccineDashboardData, ComputedVaccineStatus } from '../../../../../services/baby-care.service';
import { AuthService } from '../../../../../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-patient-baby-care',
  templateUrl: './patient-baby-care.component.html',
  styleUrls: ['./patient-baby-care.component.scss']
})
export class PatientBabyCareComponent implements OnInit {
  activeSection: string = 'dashboard';
  isFirstTime: boolean = false;
  isLoading: boolean = true;
  
  // Real Data
  baby: BabyDashboard | null = null;
  vaccineData: VaccineDashboardData | null = null;
  journalLogs: any[] = [];
  onboardingPhoto: string | null = null;
  
  get parentRole() {
    return this.authService.getParentRole();
  }

  summaries: any = {
    sleep: { totalMins: 0, targetMins: 840, count: 0 },
    feeding: { totalMl: 0, sessionCount: 0, lastTime: 'N/A' },
    diaper: { total: 0, wet: 0, dirty: 0 },
    health: { latest: 'N/A', status: 'Normal' }
  };

  currentSleepTimer: { startTime: number, elapsed: string } | null = null;
  timerInterval: any;

  get userName() {
    const fullName = this.authService.getUserFullName() || 'Sarah';
    return fullName.split(' ')[0];
  }

  // Assets & Placeholders
  defaultMamaAvatar = 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=512&auto=format&fit=crop';
  defaultBabyAvatar = 'https://images.unsplash.com/photo-1519689680058-324335c75eba?q=80&w=512&auto=format&fit=crop';

  // Onboarding Form
  onboardingForm!: FormGroup;

  sections = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fas fa-th-large' },
    { id: 'vaccination', label: 'Vaccination', icon: 'fas fa-syringe' },
    { id: 'feeding', label: 'Feeding', icon: 'fas fa-baby-bottle' },
    { id: 'sleep', label: 'Sleep', icon: 'fas fa-moon' },
    { id: 'diaper', label: 'Diaper', icon: 'fas fa-cloud' },
    { id: 'milestones', label: 'Milestones', icon: 'fas fa-chart-line' },
    { id: 'ai-help', label: 'AI Help', icon: 'fas fa-robot' },
    { id: 'journal', label: 'Journal', icon: 'fas fa-book' },
    { id: 'settings', label: 'Settings', icon: 'fas fa-cog' }
  ];

  activeAgeTab: string = '4-6';

  feedingGuides: any = {
    '0-3': {
      title: '0–3 Months — Breast Milk Only',
      description: 'Breast milk or formula is the only food your baby needs. This is providing complete nutrition and immunity. Do not introduce any solids yet.',
      tags: ['🤱 Breast or Formula Only', '⏱ Feed on demand'],
      foods: [
        { emoji: '🤱', name: 'Breast Milk', benefit: 'Complete nutrition' },
        { emoji: '🍼', name: 'Formula', benefit: 'Complete nutrition' }
      ]
    },
    '4-6': {
      title: '4–6 Months — Starting Solids',
      description: 'Breast milk or formula remains primary nutrition. Around 4–6 months, you can begin introducing single-ingredient purées — starting with iron-rich foods. Look for signs of readiness: sitting with support, showing interest in food, losing the tongue-thrust reflex.',
      tags: ['🤱 Breast or Formula First', '1 new food/week'],
      foods: [
        { emoji: '🥕', name: 'Carrot', benefit: 'Vitamin A' },
        { emoji: '🥦', name: 'Broccoli', benefit: 'Iron + Folate' },
        { emoji: '🍠', name: 'Sweet potato', benefit: 'Energy' },
        { emoji: '🍌', name: 'Banana', benefit: 'Potassium' },
        { emoji: '🍐', name: 'Pear', benefit: 'Digestion' },
        { emoji: '🥣', name: 'Oat porridge', benefit: 'Iron + Zinc' }
      ]
    },
    '7-9': {
      title: '7–9 Months — Thicker Textures',
      description: 'Offer mashed and finely chopped foods 2–3 times a day. Keep breastfeeding. Introduce protein-rich foods like lentils, chicken, and egg yolk.',
      tags: ['🥄 Mashed textures', '2–3 meals/day'],
      foods: [
        { emoji: '🍗', name: 'Chicken', benefit: 'Protein + Iron' },
        { emoji: '🥚', name: 'Egg yolk', benefit: 'Choline + Protein' },
        { emoji: '🫘', name: 'Lentils', benefit: 'Protein + Iron' },
        { emoji: '🥑', name: 'Avocado', benefit: 'Healthy fats' },
        { emoji: '🫐', name: 'Blueberries', benefit: 'Antioxidants' },
        { emoji: '🌾', name: 'Oats', benefit: 'Iron + Fiber' }
      ]
    },
    '10-12': {
      title: '10–12 Months — Family Foods',
      description: 'Your baby can now eat soft pieces of most family foods. Offer 3 meals and 2 snacks daily. Keep breastfeeding. Introduce a sippy cup.',
      tags: ['🍽 3 meals + 2 snacks', '🥛 Start sippy cup'],
      foods: [
        { emoji: '🐟', name: 'Fish', benefit: 'Omega-3 + Protein' },
        { emoji: '🧀', name: 'Cheese', benefit: 'Calcium' },
        { emoji: '🍳', name: 'Whole egg', benefit: 'Complete protein' },
        { emoji: '🫘', name: 'Beans', benefit: 'Fiber + Iron' },
        { emoji: '🥦', name: 'Broccoli', benefit: 'Vitamins' },
        { emoji: '🍚', name: 'Rice', benefit: 'Energy' }
      ]
    },
    '1-2yr': {
      title: '1–2 Years — Toddler Diet',
      description: 'Congratulations! Your baby is now a toddler. Cow\'s milk can now replace breast milk if desired. Offer a varied diet with 3 meals plus snacks.',
      tags: ['🥛 Cow\'s milk OK now', '🌈 Variety is key'],
      foods: [
        { emoji: '🥛', name: "Cow's milk", benefit: 'Calcium + Vitamin D' },
        { emoji: '🍖', name: 'Meat', benefit: 'Iron + Protein' },
        { emoji: '🥕', name: 'Vegetables', benefit: 'Vitamins' },
        { emoji: '🍎', name: 'Fruit', benefit: 'Fiber + Sugar' },
        { emoji: '🥜', name: 'Nut butters', benefit: 'Healthy fats' },
        { emoji: '🍞', name: 'Whole grain', benefit: 'Fiber + Energy' }
      ]
    }
  };

  milestonesData: any = {
    physical: [
      { title: 'Holds head steady', description: 'During tummy time and when held upright — neck muscles are getting strong!', achieved: true },
      { title: 'Pushes up on forearms', description: 'During tummy time, pushing up is excellent upper body development.', achieved: true },
      { title: 'Rolls from tummy to back', description: 'Some babies begin rolling around 4–5 months. Encourage with gentle play.', achieved: false }
    ],
    sensory: [
      { title: 'Follows moving objects with eyes', description: 'Tracking toys and faces is a sign of healthy visual development.', achieved: true },
      { title: 'Laughs and makes sounds', description: 'Cooing, squealing, and first laughs — early language is blooming.', achieved: true }
    ],
    social: [
      { title: 'Smiles spontaneously, especially at people', description: 'Social smiling shows strong emotional bonding and attachment.', achieved: true },
      { title: 'Shows excitement with familiar faces', description: 'Looking for your face, reaching arms up — attachment is deepening.', achieved: false }
    ]
  };

  constructor(
    private babyService: BabyCareService,
    public authService: AuthService,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.onboardingForm = this.fb.group({
      name: ['', Validators.required],
      birthDate: ['', Validators.required],
      gender: ['UNKNOWN'],
      birthWeight: [null, [Validators.min(0)]],
      birthHeight: [null, [Validators.min(0)]],
      priorities: [[]]
    });
    this.checkBabyProfile();
    this.onboardingPhoto = localStorage.getItem('onboarding_photo');
  }

  checkBabyProfile() {
    const userId = this.authService.getUserId();
    if (!userId) return;

    this.babyService.getProfileByPatientId(userId).subscribe({
      next: (profile: BabyProfile) => {
        if (profile) {
          this.loadAllData(); // Use loadAllData to fetch all dashboard related data
        } else {
          this.isFirstTime = true;
          this.isLoading = false;
        }
      },
      error: () => {
        this.isFirstTime = true;
        this.isLoading = false;
      }
    });
  }

  saveOnboarding() {
    const parentId = this.authService.getUserId();
    if (!parentId || this.onboardingForm.invalid) return;

    const data = { ...this.onboardingForm.value, photoUrl: this.onboardingPhoto };
    this.babyService.createProfile(parentId, data).subscribe({
      next: (profile) => {
        this.isFirstTime = false;
        localStorage.removeItem('onboarding_photo');
        this.loadAllData(); // Use loadAllData after onboarding
      },
      error: () => alert('Failed to save profile')
    });
  }

  handlePhotoUpload(event: any, isDashboard: boolean = true): void {
    const file = event.target.files[0];
    if (!file) return;

    // Validation
    if (!file.type.startsWith('image/')) {
      alert('Only image files are allowed');
      return;
    }
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      alert('File is too large (max 5MB)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e: any) => {
      const base64 = e.target.result;
      if (isDashboard && this.baby) {
        this.babyService.updateProfilePhoto(this.baby!.id, base64).subscribe(() => {
          if (this.baby) this.baby.photoUrl = base64;
        });
      } else {
        this.onboardingPhoto = base64;
        localStorage.setItem('onboarding_photo', base64);
      }
    };
    reader.readAsDataURL(file);
  }

  loadAllData() {
    const userId = this.authService.getUserId();
    if (!userId) return;
    this.isLoading = true;

    this.babyService.getProfileByPatientId(userId).subscribe({
      next: (profile) => {
        this.isFirstTime = false;
        this.babyService.getDashboard(profile.id).subscribe(dash => {
          this.baby = dash;
          this.isLoading = false;
          this.loadSummaries();
          this.loadVaccines();
          this.loadJournal();
        });
      },
      error: () => {
        this.isFirstTime = true;
        this.isLoading = false;
      }
    });
  }

  loadSummaries() {
    if (!this.baby) return;
    this.babyService.getCategorySummaries(this.baby.id).subscribe(s => this.summaries = s);
  }

  startSleepTimer() {
    const startTime = Date.now();
    this.currentSleepTimer = { startTime, elapsed: '00:00:00' };
    this.timerInterval = setInterval(() => {
      const diff = Date.now() - startTime;
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      this.currentSleepTimer!.elapsed = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
    }, 1000);
  }

  stopSleepTimer() {
    if (!this.currentSleepTimer || !this.baby) return;
    clearInterval(this.timerInterval);
    const duration = Math.floor((Date.now() - this.currentSleepTimer.startTime) / 60000);
    this.babyService.addJournalEntry(this.baby.id, 'SLEEP', `Slept for ${duration} mins`, 'Timer log', { duration })
      .subscribe(() => {
        this.currentSleepTimer = null;
        this.loadAllData();
      });
  }

  toggleMilestone(m: any) {
    m.achieved = !m.achieved;
    // Persist if needed
  }

  loadVaccines() {
    if (!this.baby) return;
    this.babyService.getVaccines(this.baby.id).subscribe(data => this.vaccineData = data);
  }

  toggleVaccineStatus(vaccine: ComputedVaccineStatus) {
    if (!this.baby) return;
    
    // If it's done, remove the record
    if (vaccine.status === 'done' && vaccine.record) {
      if (confirm(`Unmark ${vaccine.definition.name} as completed?`)) {
        this.babyService.removeVaccineRecord(vaccine.record.id).subscribe(() => {
          this.loadVaccines();
        });
      }
    } else {
      // Mark as done
      const today = new Date().toISOString().split('T')[0];
      const customDate = prompt(`Enter completion date for ${vaccine.definition.name} (YYYY-MM-DD):`, today);
      if (customDate) {
        this.babyService.recordVaccineComplete(this.baby.id, vaccine.definition.id, customDate).subscribe(() => {
          this.loadVaccines();
        });
      }
    }
  }

  loadJournal() {
    if (!this.baby) return;
    this.babyService.getJournal(this.baby.id).subscribe(data => this.journalLogs = data);
  }

  setSection(id: string) {
    this.activeSection = id;
  }

  togglePriority(p: string) {
    const currentPriorities = this.onboardingForm.get('priorities')?.value || [];
    const index = currentPriorities.indexOf(p);
    let updated;
    if (index > -1) {
      updated = currentPriorities.filter((item: string) => item !== p);
    } else {
      updated = [...currentPriorities, p];
    }
    this.onboardingForm.patchValue({ priorities: updated });
  }

  // ====== JOURNAL ======
  journalFilter: string = 'all';
  showAddEntry: boolean = false;
  journalDate: Date = new Date();

  newEntry: any = { 
    type: 'FEEDING', 
    value: '', 
    notes: '', 
    subType: 'BREAST', 
    quantity: 120, 
    duration: 15, 
    side: 'BOTH',
    stoolColor: 'Yellow',
    rash: false,
    medication: ''
  };

  get journalDateLabel(): string {
    const today = new Date();
    const d = this.journalDate;
    if (d.toDateString() === today.toDateString()) return 'Today';
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
    return d.toLocaleDateString('en-US', { weekday: 'long' });
  }

  get journalDateFormatted(): string {
    return this.journalDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  }

  setJournalFilter(filter: string) {
    this.journalFilter = filter;
    if (filter !== 'all') {
      this.newEntry.type = filter;
    }
  }

  get currentJournalConfig() {
    const configs: any = {
      'FEEDING': { label: 'Feeding', placeholder: 'e.g. Breastfed 20 min, left side...', icon: '🍼' },
      'SLEEP': { label: 'Sleep', placeholder: 'e.g. Morning nap, slept 1h 45min...', icon: '🌙' },
      'DIAPER': { label: 'Diaper', placeholder: 'e.g. Wet diaper, changed at 10:30 AM...', icon: '💧' },
      'TEMP': { label: 'Temperature', placeholder: 'e.g. 37.8°C, checked after nap...', icon: '🌡️' },
      'NOTE': { label: 'Note', placeholder: 'e.g. Baby seem exceptionally happy today...', icon: '📝' }
    };
    return configs[this.newEntry.type] || configs['FEEDING'];
  }

  // Demo log entries that would normally come from the backend
  demoLogs: any[] = [
    { time: '8:30\nAM', type: 'FEEDING', icon: '🤱', iconBg: '#fce4ec', title: 'Breastfed', detail: 'Left side 12 min · Right side 8 min · Sofia seemed satisfied after', badge: '20 mins total', badgeBg: '#f3e8ff', badgeColor: '#6b21a8' },
    { time: '9:15\nAM', type: 'DIAPER', icon: '💧', iconBg: '#e0f7fa', title: 'Diaper Change', detail: 'Wet · Normal yellow · No rash noted', badge: '✓ Normal', badgeBg: '#e8f5e9', badgeColor: '#2e7d32' },
    { time: '10:00\nAM', type: 'SLEEP', icon: '🌙', iconBg: '#fff8e1', title: 'Nap — Morning', detail: 'Fell asleep in crib · Woke at 11:45 AM · Seemed well rested', badge: '1h 45min', badgeBg: '#fff3cd', badgeColor: '#856404' },
    { time: '12:10\nPM', type: 'FEEDING', icon: '🤱', iconBg: '#fce4ec', title: 'Breastfed', detail: 'Right side 15 min · A bit fussy at the start but settled', badge: '15 mins', badgeBg: '#f3e8ff', badgeColor: '#6b21a8' },
    { time: '2:00\nPM', type: 'TEMP', icon: '🌡️', iconBg: '#fde8ff', title: 'Temperature Check', detail: 'Felt a little warm — checked temperature', badge: '37.8°C — Monitor', badgeBg: '#fff0f0', badgeColor: '#c53030' }
  ];

  get filteredLogs(): any[] {
    const combined = [...this.journalLogs, ...this.demoLogs];
    if (this.journalFilter === 'all') return combined;
    return combined.filter(l => l.type === this.journalFilter);
  }

  prevDay() { const d = new Date(this.journalDate); d.setDate(d.getDate() - 1); this.journalDate = d; }
  nextDay() { const d = new Date(this.journalDate); d.setDate(d.getDate() + 1); this.journalDate = d; }

  submitJournalEntry() {
    if (!this.baby || !this.newEntry.value) return;
    
    // Prepare metadata based on type
    const metadata: any = {};
    if (this.newEntry.type === 'FEEDING') {
      metadata.subType = this.newEntry.subType;
      metadata.quantity = this.newEntry.quantity;
      metadata.side = this.newEntry.side;
    } else if (this.newEntry.type === 'SLEEP') {
      metadata.duration = this.newEntry.duration;
    } else if (this.newEntry.type === 'DIAPER') {
      metadata.subType = this.newEntry.subType;
      metadata.stoolColor = this.newEntry.stoolColor;
      metadata.rash = this.newEntry.rash;
    }

    this.babyService.addJournalEntry(this.baby.id, this.newEntry.type, this.newEntry.value, this.newEntry.notes, metadata)
      .subscribe({
        next: () => {
          this.showAddEntry = false;
          this.resetNewEntry();
          this.loadAllData(); // Fully refresh dashboard metrics
        },
        error: () => alert('Failed to save entry')
      });
  }

  resetNewEntry() {
    this.newEntry = { 
      type: this.newEntry.type, 
      value: '', 
      notes: '', 
      subType: this.newEntry.type === 'FEEDING' ? 'BREAST' : (this.newEntry.type === 'DIAPER' ? 'WET' : ''), 
      quantity: 120, 
      duration: 15, 
      side: 'BOTH',
      stoolColor: 'Yellow',
      rash: false,
      medication: ''
    };
  }
}
