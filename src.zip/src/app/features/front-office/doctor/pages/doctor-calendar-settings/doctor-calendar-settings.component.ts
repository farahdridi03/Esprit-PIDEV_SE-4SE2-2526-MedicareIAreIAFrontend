import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { ScheduleService } from '../../../../../services/schedule.service';
import { AvailabilityService } from '../../../../../services/availability.service';
import { AuthService } from '../../../../../services/auth.service';
import { WeeklySchedule, DaySchedule, TimeSlot, CalendarAvailability } from '../../../../../models/schedule.model';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-doctor-calendar-settings',
  templateUrl: './doctor-calendar-settings.component.html',
  styleUrls: ['./doctor-calendar-settings.component.scss']
})
export class DoctorCalendarSettingsComponent implements OnInit {
  scheduleForm!: FormGroup;
  providerId!: number;
  isLoading = false;
  isSaving = false;
  successMessage = '';
  errorMessage = '';
  selectedDate: Date = new Date();
  daysInWeek: Date[] = [];

  constructor(
    private fb: FormBuilder,
    private scheduleService: ScheduleService,
    private availabilityService: AvailabilityService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.providerId = this.authService.getUserId() || 1;
    this.generateWeek(this.selectedDate);
    this.initForm();
    this.loadSchedule();
  }

  initForm(): void {
    this.scheduleForm = this.fb.group({
      days: this.fb.array([])
    });
  }

  get days(): FormArray {
    return this.scheduleForm.get('days') as FormArray;
  }

  get previewSchedule(): WeeklySchedule {
    return {
      providerId: this.providerId,
      days: this.scheduleForm.value.days
    };
  }

  timeSlots(dayIndex: number): FormArray {
    return this.days.at(dayIndex).get('timeSlots') as FormArray;
  }

  loadSchedule(): void {
    this.isLoading = true;
    this.errorMessage = '';
    
    console.log(`[DEBUG] Initializing load for providerId: ${this.providerId}`);
    
    // In this view, we primarily load the TEMPLATE as the base structure
    this.scheduleService.getWeeklySchedule(this.providerId).subscribe({
      next: (schedule) => {
        console.log('[DEBUG] Template Loaded:', schedule);
        this.populateForm(schedule);
        this.isLoading = false;
      },
      error: (err) => {
        console.error('[ERROR] Failed to load schedule', err);
        this.errorMessage = 'Erreur lors du chargement du planning.';
        this.isLoading = false;
      }
    });

    // We also fetch specific slots to see if things are already in DB
    this.availabilityService.getAvailabilitiesByDoctor(this.providerId).subscribe({
      next: (slots) => {
        console.log('[DEBUG] Backend Availabilities found:', slots);
      }
    });
  }

  populateForm(schedule: WeeklySchedule): void {
    this.days.clear();
    const daysOfWeek: ('MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY' | 'SUNDAY')[] = 
      ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];

    daysOfWeek.forEach(dow => {
      // Find matching day in incoming schedule
      const existingDay = schedule.days?.find(d => d.dayOfWeek === dow);
      
      const dayFormGroup = this.fb.group({
        dayOfWeek: [dow],
        active: [existingDay?.active || false],
        timeSlots: this.fb.array(
          existingDay?.timeSlots?.length 
            ? existingDay.timeSlots.map(slot => this.createTimeSlotFormGroup(slot)) 
            : [this.createTimeSlotFormGroup()]
        )
      });
      this.days.push(dayFormGroup);
    });
  }

  createTimeSlotFormGroup(slot?: any): FormGroup {
    return this.fb.group({
      id: [slot?.id || null], // Keep track of DB ID
      startTime: [slot?.startTime || '09:00', Validators.required],
      endTime: [slot?.endTime || '12:00', Validators.required],
      mode: [slot?.mode || 'OFFICE', Validators.required]
    });
  }

  addTimeSlot(dayIndex: number): void {
    const dayOfWeek = this.days.at(dayIndex).get('dayOfWeek')?.value;
    const targetDate = this.getDateForDay(dayOfWeek);
    
    if (!targetDate) {
      this.errorMessage = "Impossible de déterminer la date pour ce jour.";
      return;
    }

    const defaultStartTime = '09:00';
    const defaultEndTime = '10:00';
    const defaultMode = 'OFFICE';

    // Build the request payload as specifically requested by USER
    const dateStr = formatDate(targetDate, 'yyyy-MM-dd', 'en-US');
    const payload: CalendarAvailability = {
      startTime: `${dateStr}T${defaultStartTime}:00`,
      endTime: `${dateStr}T${defaultEndTime}:00`,
      mode: defaultMode,
      status: 'AVAILABLE'
    };

    console.log('[DEBUG] Creating individual slot...', payload);
    
    this.availabilityService.createAvailability(this.providerId, payload).subscribe({
      next: (savedSlot) => {
        this.successMessage = "Créneau ajouté en base de données.";
        this.timeSlots(dayIndex).push(this.createTimeSlotFormGroup({
          id: savedSlot.id,
          startTime: defaultStartTime,
          endTime: defaultEndTime,
          mode: defaultMode
        } as any));
        setTimeout(() => this.successMessage = '', 2000);
      },
      error: (err) => {
        console.error('[ERROR] Failed to add slot', err);
        this.errorMessage = "Impossible de créer le créneau en base.";
        // On fallback, we still add it to UI for developer to see the discrepancy
        this.timeSlots(dayIndex).push(this.createTimeSlotFormGroup());
      }
    });
  }

  removeTimeSlot(dayIndex: number, slotIndex: number): void {
    const slotGroup = this.timeSlots(dayIndex).at(slotIndex);
    const id = slotGroup.get('id')?.value;

    if (id) {
      console.log(`[DEBUG] Deleting slot ID: ${id}`);
      this.availabilityService.deleteAvailability(id).subscribe({
        next: () => {
          this.timeSlots(dayIndex).removeAt(slotIndex);
          this.successMessage = "Supprimé de la base.";
          setTimeout(() => this.successMessage = '', 2000);
        },
        error: (err) => {
          console.error('[ERROR] Delete failed', err);
          this.errorMessage = "Erreur lors de la suppression en base.";
        }
      });
    } else {
      // Local only (not yet saved)
      this.timeSlots(dayIndex).removeAt(slotIndex);
    }
  }

  toggleDay(dayIndex: number): void {
    const dayControl = this.days.at(dayIndex).get('active');
    dayControl?.setValue(!dayControl.value);
  }

  saveSchedule(): void {
    if (this.scheduleForm.invalid) {
      this.scheduleForm.markAllAsTouched();
      return;
    }

    this.isSaving = true;
    this.successMessage = '';
    this.errorMessage = '';

    const payload: WeeklySchedule = {
      providerId: this.providerId,
      days: this.scheduleForm.value.days
    };

    this.scheduleService.saveWeeklySchedule(this.providerId, payload).subscribe({
      next: () => {
        this.successMessage = 'Votre planning hebdomadaire a été enregistré avec succès.';
        this.isSaving = false;
        setTimeout(() => this.successMessage = '', 4000);
      },
      error: () => {
        this.errorMessage = 'Erreur lors de la sauvegarde du planning.';
        this.isSaving = false;
      }
    });
  }

  getDayName(dayOfWeek: string): string {
    const names: Record<string, string> = {
      MONDAY: 'Lundi',
      TUESDAY: 'Mardi',
      WEDNESDAY: 'Mercredi',
      THURSDAY: 'Jeudi',
      FRIDAY: 'Vendredi',
      SATURDAY: 'Samedi',
      SUNDAY: 'Dimanche'
    };
    return names[dayOfWeek] || dayOfWeek;
  }

  generateWeek(baseDate: Date): void {
    const startOfWeek = new Date(baseDate);
    const day = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - day + (day === 0 ? -6 : 1); // Adjust to Monday
    startOfWeek.setDate(diff);

    this.daysInWeek = [];
    for (let i = 0; i < 7; i++) {
        const d = new Date(startOfWeek);
        d.setDate(startOfWeek.getDate() + i);
        this.daysInWeek.push(d);
    }
  }

  nextWeek(): void {
    this.selectedDate.setDate(this.selectedDate.getDate() + 7);
    this.generateWeek(this.selectedDate);
  }

  prevWeek(): void {
    this.selectedDate.setDate(this.selectedDate.getDate() - 7);
    this.generateWeek(this.selectedDate);
  }

  getDateForDay(dayOfWeek: string): Date | undefined {
    const dayNames = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    return this.daysInWeek.find(d => dayNames[d.getDay()] === dayOfWeek);
  }
}
